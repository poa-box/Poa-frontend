# Coding-agent integration recipe

Choose a task in [getting started](getting-started.md) or the companion
[workflow recipes](workflow-recipes.v1.json) ([schema](workflow-recipes.schema.json)).
These specify public imports, input units, effects, result branches and example
checks for reads, unsigned task/poll/vote preparation, staged roles and recovery.
The [role-operation catalog](operation-manifest.v1.json) retains its version-1
shape and describes only the five role-operation functions.


Use one reviewed `@poa-box/core@2.2.0` candidate archive for protocol and browser
runtime integration; the published 2.1.0 release remains unchanged. Public
`@poa-box/core/browser/*` adapters and `@poa-box/core/workflows` share the core
version. Read the [browser integration guide](browser-integration.md) and
[feature catalog](browser-features.v1.json) for complete operation setup and
supported boundaries. Protocol-only unsigned recipes retain their 2.1.0 minimum.

Use the public packed SDK, not frontend internals or CLI subprocesses, for a JS
host. Read [role-operations.md](role-operations.md) and the static
[version-1 catalog](operation-manifest.v1.json) against its
[schema](operation-manifest.schema.json). This catalog describes five role functions;
it is not a runtime operation engine or the CLI command manifest.

Start with ordinary organization/permission reads and bounded evidence. Keep
indexed data primary; retain its own endpoint/block/coverage even when targeted
RPC observations complete the request. Unknown is not false or a zero total.
An exported provider interface does not prove a deployed counter exists.

Use `readRoleOperationEvidence` with `purpose: 'capabilities'` only to load form
options from available bound modules, including with a blank staged role name.
Its evidence explicitly records that purpose. Absent modules stay absent, known
false facts stay false and unavailable proof stays unknown. This performs no
subject prediction, holder-grant/registration work or history scan and supplies
no change authorization. The default purpose is `operation`; review does not
accept a purpose and forces strict operation evidence even for JavaScript callers.
Prepare/revalidate renew that review and status independently proves exact outcomes.

Review first, display consequences, then obtain visible stage-specific approval.
Review reads but never uploads. Prepare can publicly and irreversibly publish
only exact reviewed bytes through an explicitly injected trusted publisher. It
cannot send. Build the enclosing proposal with existing helpers, revalidate after
its async preparation, then use host transport and the versioned unsigned journal.
All payable adapters must forward exact native wei; never coerce an ID/value to
Number. Reject unsupported value transport before dispatch.

After timeout/reload, recover the original journal read-only. Never automatically
resend or treat an outer receipt as inner success. Actual-ID proof and separate
configuration outcome come from `readRoleOperationStatus`. Its configuration proof
requires a separate proposal and binds every supported call to the actual created
subject. Supply the optional read-only `fetchDocument(cid, { signal })` for a
configuration allowlist; at most one root/org-verified document is read. Missing
documents or unrelated/unsupported calls stay unknown with the creation proof
retained. Opaque review/prepared
handles lose authority when serialized; re-review from current evidence after reload.
Retain the original review's `requiresConfiguration` as host draft/display intent.
Status cannot infer that intent and returns `review-configuration` after proven
creation even for create-only requests. When no deferred settings were requested,
the exact created proof completes the workflow; do not submit an empty second vote.
The application owns scope, cache, consent UI and wallet selection. Optional
core browser adapters supply generation fences, durable journals, account locks
and dispatch guards; the application must configure and use those boundaries. No private key is needed for public reads.

Default [consumer](https://github.com/poa-box/poa-cli/tree/main/examples/role-consumer) output is synthetic
and network-free. Explicit real-read mode accepts public inputs only and supplies
no signing or publisher capability. Real endpoint availability, module bytecode,
index population, packed/browser closure and frontend/Test6 behavior each require
separate evidence. Passkey cashout and eventless-native completeness are excluded.
